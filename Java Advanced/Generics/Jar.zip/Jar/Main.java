package Advanced.Generics.Jar;

public class Main {
    public static void main(String[] args) {

        Jar<Integer> jar = new Jar<>();
        jar.addElement(150);
        System.out.println(jar.removeElement());
    }
}
